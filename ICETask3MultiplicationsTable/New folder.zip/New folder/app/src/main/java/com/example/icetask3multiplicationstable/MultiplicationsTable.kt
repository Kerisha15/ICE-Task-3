package com.example.icetask3multiplicationstable

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MultiplicationsTable : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_multiplications_table

            val bundle: Bundle? = intent.extras
            val tableString: String? = bundle?.getString("tableNumber")






    }
}